export class Reminder {
  id: Number;
  reminderName: string;
  reminderDesc: string;
  reminderType: string;
  reminderCreatedBy: string;
  reminderCreationDate: Date = new Date();
  constructor() {
    this.reminderName = '';
    this.reminderDesc = '';
    this.reminderType = '';
	this.reminderCreatedBy = '';
    this.reminderCreationDate = new Date();
  }
}
