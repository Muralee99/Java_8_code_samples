import { DatepickerOptions } from 'ng2-datepicker';
import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';
import { Note } from '../note';
import { NotesService } from '../services/notes.service';
import { AmazingTimePickerService } from 'amazing-time-picker'; // this line you need


@Component({
  selector: 'app-note-taker',
  templateUrl: './note-taker.component.html',
  styleUrls: ['./note-taker.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class NoteTakerComponent implements OnInit {

options: DatepickerOptions = {
  minYear: 1970,
  maxYear: 2030,
  displayFormat: 'MMM D[,] YYYY',
  barTitleFormat: 'MMMM YYYY',
  dayNamesFormat: 'dd',
  firstCalendarDay: 0, // 0 - Sunday, 1 - Monday
  minDate: new Date(Date.now()), // Minimal selectable date
  maxDate: new Date(Date.now()),  // Maximal selectable date
  barTitleIfEmpty: 'Click to select a date',
  placeholder: 'Click to select a date', // HTML input placeholder attribute (default: '')
  addClass: 'form-control', // Optional, value to pass on to [ngClass] on the input field
  addStyle: {}, // Optional, value to pass to [ngStyle] on the input field
  fieldId: 'my-date-picker', // ID to assign to the input field. Defaults to datepicker-<counter>
  useEmptyBarTitle: false, // Defaults to true. If set to false then barTitleIfEmpty will be disregarded and a date will always be shown 
};

 date : Date = new Date();
 settings = {
	bigBanner: true,
	timePicker: true,
	format: 'dd-MM-yyyy hh:mm a',
	defaultOpen: false,
	closeOnSelect: false
 };
 
  note:  Note = new Note();
  notes:  Array<Note> = [];
  errMessage: string;
  constructor(private atp: AmazingTimePickerService, private notesService: NotesService  ) {
  }
  ngOnInit() {
  }

 /* open() {
    const amazingTimePicker = this.atp.open();
    amazingTimePicker.afterClose().subscribe(time => {
      console.log(time);
    });*/

  takeNotes() {
    if ( ( this.note.title.length > 0 ) || ( this.note.text.length > 0 ) ) {
    this.notesService.addNote(this.note).subscribe(
      data => {},
      err => {
                this.errMessage =  err.error ? err.error.message : err.message;
                const index: number = this.notes.findIndex(note => note.title === this.note.title);
                this.notes.splice(index, 1);
      });
    this.note = new Note();
    } else {
          this.errMessage = 'Title and Text both are required fields';
    }
}
}
