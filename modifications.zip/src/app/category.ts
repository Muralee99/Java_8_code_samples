export class Category {
  id: Number;
  categoryName: string;
  categoryDesc: string;
  createdBy: string;
  creattionDate: Date = new Date();
  constructor() {
    this.categoryName = '';
    this.categoryDesc = '';
    this.createdBy = '';
	this.creattionDate = new Date();    
  }
}
